package com.elsys.stan;

import com.elsys.stan.shared.transferable.ShopTransferable;
import com.larvalabs.svgandroid.SVG;
import com.larvalabs.svgandroid.SVGParser;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ShopScrollActivity extends Activity implements OnClickListener {
	public final int LANDSCAPE_MODE = 1;
	public final int PORTRET_MODE = 0;
	private ImageView mainImage;
	private LinearLayout imagesLayout;
	private TextView shopNameText;
	private TextView shopDescrText;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub

		super.onCreate(savedInstanceState);
		setContentView(R.layout.shop_list);
		imagesLayout = (LinearLayout) findViewById(R.id.shop_list_layout);
		mainImage = (ImageView) findViewById(R.id.currentLogo);
		shopNameText = (TextView) findViewById(R.id.shop_name_text);
		shopDescrText = (TextView) findViewById(R.id.shop_descr_text);

		for (ShopTransferable s : ShopService.myBuilding.getShopList()) {

			ImageView image = new ImageView(getApplicationContext());
			SVG svg = SVGParser.getSVGFromString(s.getPicture());
			Drawable drawable = svg.createPictureDrawable();
			image.setImageDrawable(drawable);
			image.setOnClickListener(this);
			image.setTag(s);
			int value ;
			if (getScreenOrientation() == LANDSCAPE_MODE) {
				value = (int) TypedValue.applyDimension(
						TypedValue.COMPLEX_UNIT_DIP, (float) 60, getResources()
								.getDisplayMetrics());
			} else {
				value = (int) TypedValue.applyDimension(
						TypedValue.COMPLEX_UNIT_DIP, (float) 80, getResources()
								.getDisplayMetrics());
			}
			LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
					value, LinearLayout.LayoutParams.FILL_PARENT);   
			params.setMargins(0, 0, 20, 0);

			image.setLayoutParams(params);
			imagesLayout.addView(image);
		}
	}

	public void onClick(View v) {
	
		Shop s = (Shop) v.getTag();
		SVG svg = SVGParser.getSVGFromString(s.getSvg());
		Drawable drawable = svg.createPictureDrawable();
		mainImage.setImageDrawable(drawable);
		shopNameText.setText("Shop: " + s.getShopName() + " Floor: "
				+ s.getShopFloor());
		shopDescrText.setText(s.getShopDescr());

	}

	private int getScreenOrientation() {
		Display display = ((WindowManager) getSystemService(WINDOW_SERVICE))
				.getDefaultDisplay();
		return display.getOrientation();
	}
}
