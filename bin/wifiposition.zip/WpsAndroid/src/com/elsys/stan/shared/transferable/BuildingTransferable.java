package com.elsys.stan.shared.transferable;

import java.util.ArrayList;
import java.util.List;

public class BuildingTransferable {
	private int id;
	private int rev;
	private int floorNumber;
	private List<ShopTransferable> shopList;
	private List<MapTransferable> maps;
	private List<WifiApEntity> apList;
	private String administrator;
	private String name;
	private String desc;

	public BuildingTransferable() {
		// TODO Auto-generated constructor stub
	}

	public BuildingTransferable(int id, int rev, int floorNumber,
			List<ShopTransferable> shopList, List<MapTransferable> maps,
			List<WifiApEntity> apList, String administrator,
			String name, String desc) {
		super();
		this.id = id;
		this.rev = rev;
		this.floorNumber = floorNumber;
		this.shopList = shopList;
		this.maps = maps;
		this.apList = apList;
		this.administrator = administrator;
		this.name = name;
		this.desc = desc;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAdministrator() {
		return administrator;
	}

	public void setAdministrator(String administrator) {
		this.administrator = administrator;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public int getRev() {
		return rev;
	}

	public void setRev(int rev) {
		this.rev = rev;
	}

	public int getFloorNumber() {
		return floorNumber;
	}

	public void setFloorNumber(int floorNumber) {
		this.floorNumber = floorNumber;
	}

	public List<ShopTransferable> getShopList() {
		return shopList;
	}

	public void setShopList(List<ShopTransferable> shopList) {
		this.shopList = shopList;
	}

	public List<MapTransferable> getMaps() {
		return maps;
	}

	public void setMaps(List<MapTransferable> maps) {
		this.maps = maps;
	}

	public List<WifiApEntity> getApList() {
		return apList;
	}

	public void setApList(List<WifiApEntity> apList) {
		this.apList = apList;
	}

}
