package com.elsys.stan.shared.transferable;

import java.io.Serializable;



public class ShopTransferable implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4483799099002059578L;
	private String shopName;
	private String shopDescr;
	private int shopFloor;
	private double x;
	private double y;
	private String picture;

	

	public ShopTransferable(String shopName, String shopDescr, int shopFloor,
			double x, double y, String picture) {
		super();
		this.shopName = shopName;
		this.shopDescr = shopDescr;
		this.shopFloor = shopFloor;
		this.x = x;
		this.y = y;
		this.picture = picture;
	}
	
	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public ShopTransferable() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getShopDescr() {
		return shopDescr;
	}

	public void setShopDescr(String shopDescr) {
		this.shopDescr = shopDescr;
	}

	public int getShopFloor() {
		return shopFloor;
	}

	public void setShopFloor(int shopFloor) {
		this.shopFloor = shopFloor;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

}
