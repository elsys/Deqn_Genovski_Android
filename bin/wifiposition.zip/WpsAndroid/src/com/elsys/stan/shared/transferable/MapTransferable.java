package com.elsys.stan.shared.transferable;

import java.io.Serializable;
import java.util.List;




public class MapTransferable implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4650598061747671962L;
	private String svg;
	private int floor;
	private double height;
	private double width;
	
	
	public MapTransferable() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MapTransferable(String svg, int floor, double height, double width) {
		super();
		this.svg = svg;
		this.floor = floor;
		this.height = height;
		this.width = width;
	}

	public String getSvg() {
		return svg;
	}

	public void setSvg(String svg) {
		this.svg = svg;
	}

	public int getFloor() {
		return floor;
	}

	public void setFloor(int floor) {
		this.floor = floor;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	
	
}
