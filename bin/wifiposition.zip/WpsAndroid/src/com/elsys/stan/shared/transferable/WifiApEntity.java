package com.elsys.stan.shared.transferable;




public class WifiApEntity {
	
	

	private String bssid;
	
	private double power;
	
	private double x;
	
	private double y;
	
	private int buildingID;

	

	public double getPOWER() {
		return power;
	}

	public int getBuildingID() {
		return buildingID;
	}

	public String getBSSID() {
		return bssid;
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	public WifiApEntity(String bSSID, double X, double Y, double pOWER,
			int buildingId) {
		super();

		bssid = bSSID;
		power = pOWER;
		this.x = X;
		this.y = Y;
		this.buildingID = buildingId;
	}

	public WifiApEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
