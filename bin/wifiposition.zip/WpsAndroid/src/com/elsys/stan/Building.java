package com.elsys.stan;

import java.util.ArrayList;
import java.util.List;

public class Building {
	private List<Shop> shopList = new ArrayList<Shop>();
	private String name;
	private int floors;
	private List<String> svgFloors;
	
	public Building(String name,int floors){
		this.name = name;
		this.floors = floors;
		svgFloors = new ArrayList<String>();
	}
	public List<Shop> getShopList(){
		return shopList;
	}
	public int getFloors(){
		return floors;
	}
	public String getFloorMap(int id){
		return svgFloors.get(id);
	}
	public void addSVG(String svg){
		svgFloors.add(svg);
	}
	public void addShop(Shop shop){
		shopList.add(shop);
	}
	
}
