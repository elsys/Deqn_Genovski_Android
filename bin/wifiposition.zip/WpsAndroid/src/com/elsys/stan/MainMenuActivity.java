package com.elsys.stan;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

public class MainMenuActivity extends Activity implements OnClickListener {

	MediaPlayer player;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.menu);
		ShopServiceOld.addTestShops(this, getResources());

		player = MediaPlayer.create(this, R.raw.button3);

		View startButton = findViewById(R.id.start_button);
		startButton.setOnClickListener(this);
		View exitButton = findViewById(R.id.exit_button);
		exitButton.setOnClickListener(this);
		View aboutButton = findViewById(R.id.about_button);
		aboutButton.setOnClickListener(this);
		View listButton = findViewById(R.id.list_button);
		listButton.setOnClickListener(this);
	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.about_button:
			player.start();
			Intent i1 = new Intent(this, About.class);
			startActivity(i1);

			break;
		case R.id.start_button:
			player.start();
			Intent i2 = new Intent(this, FloorsActivity.class);
			startActivity(i2);

			break;
		case R.id.list_button:
			player.start();
			Intent i3 = new Intent(this, ShopScrollActivity.class);
			startActivity(i3);

			break;
		case R.id.exit_button:
			player.start();
			finish();
			break;

		}
	}

}
