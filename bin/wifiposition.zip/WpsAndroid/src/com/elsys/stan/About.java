package com.elsys.stan;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.view.GestureDetector.OnDoubleTapListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;

public class About extends Activity implements  OnTouchListener {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.about);
		
		Button about = (Button) findViewById(R.id.about_close_button);
		about.setOnTouchListener(this);
	}

	public boolean onTouch(View v, MotionEvent event) {
		finish();
		return true;
	}

	
}
