package com.elsys.stan;

import android.graphics.drawable.BitmapDrawable;

public class Shop {
	private String shopName;
	private String shopDescr;
	private int picId;


	private int shopFloor;
	private BitmapDrawable bitmap;
	private String svg;
	private float posX;
	private float posY;

	public float getPosX() {
		return posX;
	}

	public void setPosX(float posX) {
		this.posX = posX;
	}

	public float getPosY() {
		return posY;
	}

	public void setPosY(float posY) {
		this.posY = posY;
	}

	public BitmapDrawable getBitmap() {
		return bitmap;
	}

	public void setBitmap(BitmapDrawable bm) {
		this.bitmap = bm;
	}

	public String getShopName() {
		return shopName;
	}

	public int getShopFloor() {
		return shopFloor;
	}

	public void setShopFloor(int floor) {
		this.shopFloor = floor;
	}

	public Shop(String shopName, String shopDescr,int shopFloor,float posX, float posY) {
		super();
		this.shopName = shopName;
		this.shopDescr = shopDescr;
		this.shopFloor = shopFloor;
		this.posX = posX;
		this.posY = posY;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getShopDescr() {
		return shopDescr;
	}

	public void setShopDescr(String shopDescr) {
		this.shopDescr = shopDescr;
	}

	public int getPicId() {
		return picId;
	}

	public void setPicId(int picId) {
		this.picId = picId;
	}

	public String getSvg() {
		return svg;
	}

	public void setSvg(String svg) {
		this.svg = svg;
	}
}
