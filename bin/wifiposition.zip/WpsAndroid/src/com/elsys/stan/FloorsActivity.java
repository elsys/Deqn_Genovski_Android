package com.elsys.stan;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ZoomControls;

public class FloorsActivity extends Activity {
	/** Called when the activity is first created. */
	private FloorsView floorsView;
	private ZoomControls zoomControls;
	private Button floorsButton;
	private final float SCALE_INCREMENT = 0.1f;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.floors);
		floorsButton = (Button) findViewById(R.id.buttonMapChange);
		zoomControls = (ZoomControls) findViewById(R.id.zoomControls);
		floorsView = (FloorsView) findViewById(R.id.floorsView);
		floorsButton.setOnClickListener(new OnClickListener() {

			public void onClick(View sender) {
				openOptionsMenu();
			}
		});

		zoomControls.setOnZoomInClickListener(new OnClickListener() {

			public void onClick(View v) {
				if (floorsView.getScaleFactor() < floorsView
						.getMaxScalefactor()) {
					floorsView.setScaleFactor(floorsView.getScaleFactor()
							+ SCALE_INCREMENT);
					floorsView.centerFocus();
					floorsView.invalidate();
				}
			}
		});

		zoomControls.setOnZoomOutClickListener(new OnClickListener() {
			//sad
			public void onClick(View v) {
				if (floorsView.getScaleFactor() > floorsView
						.getMinScalefactor()) {
					floorsView.setScaleFactor(floorsView.getScaleFactor()
							- SCALE_INCREMENT);
					floorsView.centerFocus();
					floorsView.invalidate();
				}

			}
		});

	}

	private void createMenu(Menu menu) {
		for (int i = 0; i < ShopService.myBuilding.getFloorNumber(); ++i) {
			menu.add(0, i, i, "Floor " + (i + 1));

		}

	}

	private boolean menuChoice(FloorsView fv,MenuItem item) {

		fv.setMap(ShopService.myBuilding.getMaps().get(item.getItemId()).getSvg());
		fv.setFloor(item.getItemId() + 1);
		return true;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		createMenu(menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		return menuChoice(floorsView,item);
	}

}
